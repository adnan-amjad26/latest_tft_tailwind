<?php
/**
 * Block Name: Platforms
 */
?>
<?php $icon = get_field('icon'); ?>
<?php $title = get_field('title'); ?>
<?php $brokers = get_field('brokers'); ?>
<?php $image = get_field('image'); ?>
<?php $image_2 = get_field('image_2'); ?>
<?php $img_day = get_field('img_day'); ?>
<?php $img_night = get_field('img_night'); ?>
<section class="platform s-padding !pt-12 bg-lilac" data-scroll-section>
    <div class="container relative z-10">
        <?php if($icon || $title): ?>
            <div class="row">
                <div class="w-full text-center">
                    <?php if($icon): ?>
                        <div class="icon mb-12 w-28 mx-auto">
                            <img decoding="async" loading="lazy" src="<?php echo $icon['url']; ?>" alt="<?php echo $icon['title']; ?>">
                        </div>
                    <?php endif; ?>
                    <?php if($title): ?>
                        <div class="title">
                            <h3><?php echo $title; ?></h3>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        <?php if($brokers || $image || $image_2): ?>
            <div class="row mt-12 lg:mt-24">
                <div class="w-full lg:w-1/2 flex justify-end img-side">
                    <?php if($image || $image_2): ?>
                        <div class="parallax-scene inline-flex">
                            <?php if($image_2): ?>
                                <div data-depth="0.8">
                                    <img decoding="async" loading="lazy" src="<?php echo $image_2['url']; ?>" alt="<?php echo $image_2['title']; ?>">
                                </div>
                            <?php endif; ?>
                            <?php if($image): ?>
                                <div data-depth="0.4">
                                    <img decoding="async" loading="lazy" src="<?php echo $image['url']; ?>" alt="<?php echo $image['title']; ?>">
                                </div>
                            <?php endif; ?>
                            <div data-depth="0.2">
                                <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/platform-gem-1.png" alt="platform-gem-1">
                            </div>
                            <div data-depth="0.2">
                                <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/platform-gem-2.png" alt="platform-gem-2">
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="w-full lg:w-2/5 mx-auto pt-12 button-side">
                    <?php if($brokers): ?>
						<?php $i = 1; foreach($brokers as $broker): ?>
							<?php $image = $broker['image']; ?>
							<figure class="max-w-md mt-12 lg:mt-16">
								<button data-broker="<?php echo $i; ?>">
									<img decoding="async" loading="lazy" src="<?php echo $image['url']; ?>" alt="<?php echo $image['title']; ?>">
								</button>
							</figure>
						<?php $i++; endforeach; ?>
						<div class="brokers-button-group">
							<?php $i = 1; foreach($brokers as $broker): ?>
								<?php $links = $broker['links']; ?>
								<?php if($links): ?>
									<div class="button-group mt-12 lg:mt-16<?php if($i == 1) echo ' active'; ?>" data-broker="<?php echo $i; ?>">
										<div class="buttons row gap-12">
											<div class="buttons row gap-12">
												<?php foreach($links as $link): ?>
													<a href="<?php echo $link['url']; ?>" target="_blank" rel="noopener noreferrer">
														<img decoding="async" loading="lazy" src="<?php echo $link['image']['url']; ?>" alt="<?php echo $link['image']['title']; ?>">
													</a>
												<?php endforeach; ?>
											</div>
										</div>
									</div>
								<?php endif; ?>
							<?php $i++; endforeach; ?>
						</div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php if($img_day || $img_night): ?>
        <figure class="bg absolute bottom-0 left-0 w-full h-full lg:h-auto z-0">
            <?php if($img_day): ?>
                <img class="imgs-day" decoding="async" loading="lazy" src="<?php echo $img_day['url']; ?>" alt="<?php echo $img_day['title']; ?>">
            <?php endif; ?>
            <?php if($img_night): ?>
                <img class="imgs-night" decoding="async" loading="lazy" src="<?php echo $img_night['url']; ?>" alt="<?php echo $img_night['title']; ?>">
            <?php endif; ?>
        </figure>
    <?php endif; ?>
</section>