<?php
/**
 * Block Name: Process
 */
?>
<?php $title = get_field('title'); ?>
<?php $text = get_field('text'); ?>
<?php $process = get_field('process'); ?>
<?php $link = get_field('link'); ?>
<section class="content-scrolls s-padding" data-scroll-section>
    <div class="container">
        <?php if($title || $subtitle): ?>
            <div class="row justify-center text-center">
                <div class="w-full lg:w-1/2">
                    <?php if($title): ?>
                        <div class="title">
                            <h3><?php echo $title; ?></h3>
                        </div>
                        <div class="hr">
                            <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/hr.svg" alt="hr">
                        </div>
                    <?php endif; ?>
                    <?php if($text): ?>
                        <div class="content mt-6 w-full text-3xl">
                            <?php echo $text; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        <?php if($process): ?>
            <div class="row mt-12 lg:mt-16">
                <ul class="toggles w-full row gap-6 lg:gap-12 justify-center font-headers text-lg">
                    <?php $i = 1; foreach($process as $type): ?>
                        <?php $button =  $type['button']; ?>
                        <li<?php if($i == 1) echo ' class="active"'; ?> data-type="type-<?php echo $i; ?>"<?php if($button) echo ' style="background-image: url('.$button.');"'; ?>><span><?php echo $type['title']; ?></span></li>
                    <?php $i++; endforeach;; ?>
                </ul>
            </div>
            <?php $i = 1; foreach($process as $type): ?>
                <?php $phases = $type['phases']; ?>
                <?php if($phases): ?>
                    <div class="scrolls-box"<?php if($i > 1) echo ' style="display: none;"'; ?> data-type="type-<?php echo $i; ?>">
                        <div class="row justify-center text-center mt-12 lg:mt-16 scrolls">
                            <?php foreach($phases as $phase): ?>
                                <div class="w-full lg:w-1/4">
                                    <div class="inner">
                                        <div class="title font-headers text-black relative">
                                            <p><?php echo $phase['title']; ?></p>
                                            <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/scroll-title.svg" alt="scroll-title">
                                        </div>
                                        <div class="content w-2/3 mx-auto pt-8">
                                            <div class="inner">
                                                <?php echo $phase['text']; ?>
                                            </div>
                                            <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/scroll-content.svg" alt="scroll-content">
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php $i++; endforeach; ?>
        <?php endif; ?>
        <?php if($link): ?>
            <div class="row justify-center mt-12 lg:mt-24">
                <div class="w-auto">
                    <div class="button">
                        <a href="<?php echo $link['url']; ?>"<?php if($link['target']) echo ' target="'.$link['target'].'"'; ?> class="btn btn-gold">
                            <span><?php echo $link['title']; ?></span>
                            <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/btn-gold-left.svg" alt="btn-gold-left">
                            <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/btn-gold-right.svg" alt="btn-gold-right">
                        </a>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>