<?php
/**
 * Block Name: Text
 */
?>
<section class="general-content s-padding z-10">
    <div class="container">
        <div class="row justify-center">
            <div class="w-full">
                <div class="content font-medium text-3xl leading-relaxed">
                    <?php the_field('text'); ?>
                </div>
            </div>
        </div>
    </div>
</section>