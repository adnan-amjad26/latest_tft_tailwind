<?php
/**
 * Block Name: FAQ
 */
?>
<?php $icon = get_field('icon'); ?>
<?php $title = get_field('title'); ?>
<?php $faq = get_field('faq'); ?>
<?php $link = get_field('link'); ?>
<?php $image = get_field('image'); ?>
<?php $image_2 = get_field('image_2'); ?>
<section class="accordion py-12 bg-green-light" data-scroll-section>
    <div class="container relative z-10">
        <?php if($icon || $title): ?>
            <div class="row">
                <div class="w-full text-center">
                    <?php if($icon): ?>
                        <div class="icon mb-12 w-28 mx-auto">
                            <img decoding="async" loading="lazy" src="<?php echo $icon['url']; ?>" alt="<?php echo $icon['title']; ?>">
                        </div>
                    <?php endif; ?>
                    <?php if($title): ?>
                        <div class="title">
                            <h3><?php echo $title; ?></h3>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endif; ?>
        <div class="row mt-12 lg:mt-16">
            <div class="w-full row justify-between">
                <?php if($faq): ?>
                    <?php $half = ceil(count($faq) / 2); ?>
                    <?php $faq_left = array_slice($faq, 0, $half); ?>
                    <?php $faq_right = array_slice($faq, $half); ?>
                    <?php if($faq_left): ?>
                        <ul class="items text-black">
                            <?php foreach($faq_left as $item): ?>
                                <li>
                                    <div class="title-wrap flex justify-between">
                                        <p class="title"><?php echo $item['question']; ?></p>
                                        <div class="toggle">
                                            <svg decoding="async"><use xlink:href="#plus"></use></svg>
                                        </div>
                                        <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/scroll-title.svg" alt="scroll-title">
                                    </div>
                                    <div class="content">
                                        <div class="inner">
                                            <?php echo $item['answer']; ?>
                                        </div>
                                        <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/scroll-content.svg" alt="scroll-content">
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                    <?php if($faq_right): ?>
                        <ul class="items text-black">
                            <?php foreach($faq_right as $item): ?>
                                <li>
                                    <div class="title-wrap flex justify-between">
                                        <p class="title"><?php echo $item['question']; ?></p>
                                        <div class="toggle">
                                            <svg decoding="async"><use xlink:href="#plus"></use></svg>
                                        </div>
                                        <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/scroll-title.svg" alt="scroll-title">
                                    </div>
                                    <div class="content">
                                        <div class="inner">
                                            <?php echo $item['answer']; ?>
                                        </div>
                                        <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/scroll-content.svg" alt="scroll-content">
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if($link): ?>
                    <div class="button mt-12 lg:mt-24 mx-auto">
                        <a href="<?php echo $link['url']; ?>" class="btn btn-gold">
                            <span><?php echo $link['title']; ?></span>
                            <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/btn-gold-left.svg" alt="btn-gold-left">
                            <img decoding="async" loading="lazy" src="<?php echo get_template_directory_uri(); ?>/img/btn-gold-right.svg" alt="btn-gold-right">
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php if($image || $image_2): ?>
        <figure class="bg absolute bottom-0 left-0 w-full z-0">
            <?php if($image): ?>
                <img class="imgs-day" src="<?php echo $image['url']; ?>" alt="<?php echo $image['title']; ?>">
            <?php endif; ?>
            <?php if($image_2): ?>
                <img class="imgs-night" src="<?php echo $image_2['url']; ?>" alt="<?php echo $image_2['title']; ?>">
            <?php endif; ?>
        </figure>
    <?php endif; ?>
</section>