<table class="table-auto overflow-scroll w-full text-center">
	<?php require __DIR__ . '/table-head.php'; ?>
	<tr class="font-montserrat font-medium text-[16px] border-b border-white border-opacity-20 xl:border-black xl:border-opacity-20">
		<td class="font-bold py-[25px] text-left">XAG-USD</td>
		<td class="py-[25px]">
			<span id="XAGUSD_BID">---</span>
			<span class="XAGUSD_Status"><i></i></span>
		</td>
		<td class="py-[25px]">
			<span id="XAGUSD_ASK">---</span>
			<span class="XAGUSD_Status"><i></i></span>
		</td>
		<td class="py-[25px]">
			<span id="XAGUSD_SPREAD">---</span>
			<span class="XAGUSD_Status"><i></i></span>
		</td>
		<td class="py-[25px]">
			<span id="XAGUSD_COMM">5.00</span>
		</td>
		<td class="py-[25px]">
			<span id="XAGUSD_PRICE">---</span>
			<span class="XAGUSD_Status"><i></i></span>
		</td>
	</tr>
	<tr class="font-montserrat  font-medium text-[16px] border-b border-white border-opacity-20 xl:border-black xl:border-opacity-20">
		<td class="font-bold py-[25px] text-left">XAU-USD</td>
		<td class="py-[25px]">
			<span id="XAUUSD_BID">---</span>
			<span class="XAUUSD_Status"><i></i></span>
		</td>
		<td class="py-[25px]">
			<span id="XAUUSD_ASK">---</span>
			<span class="XAUUSD_Status"><i></i></span>
		</td>
		<td class="py-[25px]">
			<span id="XAUUSD_SPREAD">---</span>
			<span class="XAUUSD_Status"><i></i></span>
		</td>
		<td class="py-[25px]">
			<span id="XAUUSD_COMM">5.00</span>
		</td>
		<td class="py-[25px]">
			<span id="XAUUSD_PRICE">---</span>
			<span class="XAUUSD_Status"><i></i></span>
		</td>
	</tr>
</table>
