<tr class="font-wadik text-[14px] border-b border-white xl:border-black">
	<th class="whitespace-nowrap pb-[25px] pr-[38px] text-left xl:pr-[24px]"><?= $symbol; ?></th>
	<th class="whitespace-nowrap pb-[25px] px-[38px] xl:px-6"><?= $bid_price; ?></th>
	<th class="whitespace-nowrap pb-[25px] px-[38px] xl:px-6"><?= $ask_price; ?></th>
	<th class="whitespace-nowrap pb-[25px] px-[38px] xl:px-6"><?= $spread; ?></th>
	<th class="whitespace-nowrap pb-[25px] px-[38px] xl:px-6"><?= $simulated_comissions; ?></th>
	<th class="whitespace-nowrap pb-[25px] px-[38px] xl:px-6"><?= $overall_costs; ?></th>
</tr>
