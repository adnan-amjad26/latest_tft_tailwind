<?php
/**
 * Block Name: Text
 */
?>
<section class="pb-[100px] text-white font-body font-medium leading-tight text-[16px] [&_a]:text-white [&_a]:underline [&_ul]:list-disc [&_ul]:pl-[16px] [&_ul]:my-[20px] [&_ul:last-child]:mb-0 [&_ul:first-child]:mt-0 [&_strong]:font-bold [&_p:last-child]:mb-0 [&_p]:mt-0 [&_p]:mb-[20px] [&_h2]:font-wadik [&_h2]:text-[24px] [&_h2]:mb-[25px] [&_h2]:mt-[100px] [&_h2:first-child]:mt-0 [&_h2:last-child]:mb-0 [&_h3]:font-wadik [&_h3]:text-[24px] [&_h3]:mb-[25px] [&_h3]:mt-[100px] [&_h3:first-child]:mt-0 [&_h3:last-child]:mb-0 xl:text-[24px] xl:[&_p]:mb-[30px] xl:[&_ul]:pl-[24px] xl:[&_ul]:my-[30px] xl:[&_h3]:text-[32px] xl:[&_h2]:text-[48px] xl:pb-[200px]">
	<div class="max-w-[1920px] mx-auto px-[10px] text-center md:text-left md:px-[30px] lg:px-[50px] xl:px-[110px]">
		<?php the_field('text'); ?>
	</div>

</section>
