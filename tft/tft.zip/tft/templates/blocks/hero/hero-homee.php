<?php
/**
 * Block Name: Hero Home
 */
?>
<?php

// global ${'hero-home' . '_acf_data'};
// $data = ${'hero-home' . '_acf_data'};
// // Access the variables from the provided data
// $title = $data['title'];
// $text = $data['text'];
// $link = $data['link'];
// $link_social = $data['link_social'];
// $scroll = $data['scroll'];
// $trustpilot = $data['trustpilot'];
// $trustpilot_widget = get_field('trustpilot', 'option');
// $image = wp_get_attachment_url($data['image']);
// $img_day = wp_get_attachment_url($data['img_day']);
// $img_day_2 = wp_get_attachment_url($data['img_day_2']);
// $img_night = wp_get_attachment_url($data['img_night']);
// $img_night_2 = wp_get_attachment_url($data['img_night_2']);
// $lottie_day = wp_get_attachment_url($data['lottie_day']);
// $lottie_day_2 = wp_get_attachment_url($data['lottie_day_2']);
// $lottie_day_3 = wp_get_attachment_url($data['lottie_day_3']);
// $lottie_night = wp_get_attachment_url($data['lottie_night']);
// $lottie_night_2 = wp_get_attachment_url($data['lottie_night_2']);

?>
<?php $title = get_field('title'); ?>
<?php $text = get_field('text'); ?>
<?php $link = get_field('link'); ?>
<?php $link_social = get_field('link_social'); ?>
<?php $scroll = get_field('scroll'); ?>
<?php $trustpilot = get_field('trustpilot'); ?>
<?php $trustpilot_widget = get_field('trustpilot', 'option'); ?>
<?php $image = get_field('image'); ?>
<?php $img_day = get_field('img_day'); ?>
<?php $img_day_2 = get_field('img_day_2'); ?>
<?php $img_night = get_field('img_night'); ?>
<?php $img_night_2 = get_field('img_night_2'); ?>
<?php $lottie_day = get_field('lottie_day');
?>
<?php $lottie_day_2 = get_field('lottie_day_2'); ?>
<?php $lottie_day_3 = get_field('lottie_day_3'); ?>
<?php $lottie_night = get_field('lottie_night'); ?>
<?php $lottie_night_2 = get_field('lottie_night_2'); ?>
<h1>new Hero Banner for testing</h1>