<?php
/**
 * The template for displaying no found posts
 *
 * @package CBD
 */
?>
<div class="postsNotFound">
	<?php esc_html_e('Posts not found', 'cbd'); ?>
</div>